function openAnim() {
    var tbd1 = $("#tbdecor1")[0];
	$(tbd1).animate({ marginLeft: "64px" },1000);
	tbd1.style.backgroundColor = "#FFFFFF";
	
	var tt1 = $("#toptitle1")[0];
	tt1.style.paddingTop = "40px";
	tt1.style.color = "#FFFFFF";
	tt1.style.textShadow = "0px 0px 7px #FFFFFF"
	
	var tt2 = $("#toptitle2")[0];
	//tt2.style.paddingTop = "5px";
	tt2.style.color = "#00AAFF";
	tt2.style.textShadow = "0px 0px 5px #00AAFF"
	
	//ttags
	var ttags = $(".ttag");
	for(var i = 0; i < ttags.length; i++) {
		var tt = ttags[i];
		if(i == 0)
			focusTTag(tt);
		tt.id = "e" + i;
		$(tt).mouseenter(function() { ttagJump(this); });
		$(tt).mouseleave(function() { ttagFall(this); });
		$(tt).click(function() { focusTTag(this); });
		tt.style.marginLeft = "64px";
		var transLen = 1.5+(i/10);
		tt.style.transition = transLen + "s";
		//blips
		var blip = document.createElement("img");
		blip.src = 'img/ttag-blip.png';
		blip.classList.add('ttblip');
		tt.insertBefore(blip,tt.firstChild);
		$(blip).animate({ left: "58px" },1000);
		
	}
	
	var tstamps = $(".tstamp");
	for(var i = 0; i < tstamps.length; i++) {
		var ts = tstamps[i];
		ts.style.color = "#00AAFF";
		ts.style.textShadow = "0px 0px 3px #00AAFF"
		var transLen = 1.5+(i/10);
		ts.style.transition = transLen + "s";
	}
	
	var stitles = $(".stitle");
	for(var i = 0; i < stitles.length; i++) {
		var st = stitles[i];
		st.style.color = "#FFFFFF";
		st.style.textShadow = "0px 0px 5px #FFFFFF"
		var transLen = 1.5+(i/10);
		st.style.transition = transLen + "s";
	}
	
	//select marker
	var mark = $("#tbdecor2")[0];
	mark.style.width = 0;
	$(mark).animate({ width: "50px" },1000);
	
	//scroll adjustments nvm
	//$("#scrolltop")[0].style.height = $("#toppage")[0].style.height;
}

function ttagJump(ttag) {
	ttag.style.transition = "0.5s";
	ttag.style.paddingLeft = "30px";
}

function ttagFall(ttag) {
	ttag.style.transition = "0.5s";
	ttag.style.paddingLeft = "20px";
}

function focusTTag(ttag) {
	var mark = $('#tbdecor2')[0];
	if(!$.contains(ttag, mark)) {
		$('#tbdecor2').each(function() {this.id = "tbdecor2dead";});
		var markv2 = document.createElement("div");
		markv2.id = "tbdecor2";
		markv2.style.width = "0px";
		ttag.insertBefore(markv2, ttag.firstChild);
		$(markv2).animate({ width: "50px" },500);
		$(mark).animate({ width: "0px" },500,"swing",function() {
				$('#tbdecor2dead').remove();
			});
	}
	scrollTimeline(ttag);
}

function scrollTimeline(ttag) {
	var topPos = ttag.offsetTop;
	//document.getElementById('timebar').scrollTop = topPos-200;
	$('#timebar').animate({ scrollTop: topPos-200 }, 200);
}







